# SpaceConquest

home.html : un premier écran serait la page d'acceuil  qui envoie sur "initialization.html"


initialization.html : cette page initialise le nombre joueur et la carte choisi 
(pourquoi pas faire un menu déroulant avec des mini cartes pour voir à quoi elle ressemble)

L'aventure commence !!!!

idee_du_jeu.pdf : ça serait un peu prés ça (a encore choisir les couleurs et les fonctionnalités...) de ce que j'ai pensé 
comme représentation du jeu après comme on peut choisir les flottes et tout .... j'en ai aucune idée 
pour les forme triangle et cercle ca sera pas trop difficile avec ce qu'on a vu (tp 1 html avg) qu'on poeut rendre cliquable
ce qui peut nous donner des infos.

Pourquoi pas faire une base de données du jeu (bien sur faudra faire les inscriptions avant mais pas trop dur avec les restes de
la L1) ou peut collecter des données sur le joueurs (stat de r"ussite , niveau de difficulté ...)

Bien sur avoir si on a le temps de finir le reste !

Voili voilou !
