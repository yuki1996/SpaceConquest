function Message(planet, string, player) {
  if (!(planet instanceof Planet) || !(player instanceof Player)) {
		throw new Error("maessage");
	}
  if (!(string instanceof String)) {
		throw new Error("maessage");
	}  
  this.planet = planet;
  this.string = string; 
  this.player = player;
}
