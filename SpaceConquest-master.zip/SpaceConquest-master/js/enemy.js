function Enemy(p, id) {
	if (!(p instanceof Planet)) {
		throw new Error("Enemy");
	} 
	//ensemble des planètes de l'ennemi
	this.getPlanets = [];
	this.getPlanets.push(p);
	p.leader = this;
	//la flotte de l'ennemi
	this.getFleet = [];
	this.number = id;
}

//ajout de la planète p 
Enemy.prototype.addPlanet = function(p) {
	if (p instanceof Planet) {
    p.leader = this;
		this.getPlanets.push(p);
	}
};


//Supprime la planète p
Enemy.prototype.removePlanet = function(p) {
	if (p instanceof Planet) {
    p.leader = null;
		this.getPlanets.pop(p);
	}
};

// indique si p fait partie de l'ensemble des planètes de l'ennemie
Enemy.prototype.hasPlanet = function(p) {
	if (!(p instanceof Planet)) {
		return false;
	}
  // pas supporter par les versions de Internet Explorer plus anciennes que 9
  return this.getPlanets.indexOf(p) >= 0;
};

//s'il peut encore jouer
Enemy.prototype.canPlay = function() {
	return this.getPlanets.length !== 0 || this.getFleet.length !== 0;
};

Enemy.prototype.attack = function(src, n, dst) {
  if (this.canPlay()) {
    if (!(src instanceof Planet) || !(dst instanceof Planet)) {
      throw new Error("Not planets");
    } 
    if (n < 1) {
      throw new Error("Empty spaceship!");
    }
    if (this.hasPlanet(src)) {
      if ((src.population - n) < 1) {
        throw new Error("Operation too risky: no one would be left");
      } 
      this.addSpaceship(src.buildSpaceship(n, dst));
    } else {
      throw new Error("Not your planet");
    }
  }
};

Enemy.prototype.addSpaceship = function(s) {
	if (s instanceof Spaceship) {
		this.getFleet.push(s);
	}
};

Enemy.prototype.removeSpaceShip = function(s) {
	if (s instanceof Spaceship) {
		this.getFleet = this.getFleet.filter(function(obj) {
      return obj.id !== s.id;
    });
	}
};

