<?php
  session_destroy();
  header('Location: home.html');
?>
