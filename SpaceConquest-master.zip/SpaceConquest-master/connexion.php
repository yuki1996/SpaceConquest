<?php
	try {	
			//$dsn = "mysql:host=inf-mysql.univ-rouen.fr;dbname=bouchlae";
			 $dsn ="mysql:host=localhost;dbname=chidimic";
			 $connexion = new PDO($dsn, "root", "michelle"); 
			//$connexion = new PDO($dsn, "bouchlae", "14081996"); 
		} catch (PDOException $e ) { 
			exit ('Erreur :' . $e -> getMessage ()); 
		}
		?>
