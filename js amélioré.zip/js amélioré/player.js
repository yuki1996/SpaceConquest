function Player(p) {
  if (!(p instanceof Planet)) {
		throw new Error("Player");
	} 	
  
  //la flotte de joueur
  this.getFleet = [];
  
  //propriétaire de ce planète
  p.leader = this;
  
  //ensemble des planètes du joueur
	this.getPlanets = [];
  this.getPlanets.push(p);
}

//ajout de la planète p 
Player.prototype.addPlanet = function(p) {
	if (p instanceof Planet) {
    if (!this.hasPlanet(p)) {
      p.leader = this;
      this.getPlanets.push(p);
    }
	}
};

//Supprime la planète p
Player.prototype.removePlanet = function(p) {
	if (p instanceof Planet) {
    if (this.hasPlanet(p)) {
      p.leader = null;
      var index = this.getPlanets.indexOf(p);
      this.getPlanets.splice(index);
    }
	}
};

// indique si p fait partie de l'ensemble des planètes du joueur
Player.prototype.hasPlanet = function(p) {
	if (!(p instanceof Planet)) {
		throw new Error("not a planet");
	}
  if (p.leader === this) {
    return true;
  }
  return false; 
};

//s'il peut encore jouer
Player.prototype.canPlay = function() {
	return this.getPlanets.lenghth !== 0 || this.getFleet.length !== 0;
};


// Lancer une attaque
// src est la planète de départ
// n est les nombre de colons
// dst est la planète à conquérir
Player.prototype.attack = function(src, n, dst) {
  if (!(src instanceof Planet) || !(dst instanceof Planet)) {
		throw new Error("Not planets");
	} 
  if (n < 1) {
      throw new Error("Empty spaceship!");
  }
  if (this.hasPlanet(src)) {
    if (src.population - n <= 1) {
      throw new Error("Operation too risky: no one would be left");
    }
    this.addSpaceship(src.buildSpaceship(n, dst));
  } else {
    throw new Error("Not your planet");
  }
};

Player.prototype.addSpaceship = function(s) {
	if (s instanceof Spaceship) {
		this.getFleet.push(s);
	}
};

Player.prototype.removeSpaceship = function(s) {
	if (s instanceof Spaceship) {
		this.getFleet = this.getFleet.filter(function(obj) {
      return obj.id !== s.id;
    });
	}
};

