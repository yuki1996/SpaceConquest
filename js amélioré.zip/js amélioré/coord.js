function Coord(x, y) {
	this.getX = x;
	this.getY = y;
}

Coord.prototype.isEqual = function(c) {
  if (!(c instanceof (Coord))) {
		throw new Error("Not a planet");
	}
  if (this.getX == c.getX) {
    if (this.getY == c.getY) {
      return true;
    }
  }
  return false;
};


