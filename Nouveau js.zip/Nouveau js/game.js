function Game(nbEnemy) {
	if (0 > nbEnemy || nbEnemy > 10) {
		throw new Error("Game");
	} 
	this.nbEnemy = nbEnemy;
	this.tabPlayer = new Array(nbEnemy + 1);
  
  this.fleet = []; 
  this.tabPlanet = [];
  
	this.player = null;
	var pop = this.PopulationRandom();
	var coord = new Coord(0, 1);
  var planet = new Planet(coord, pop);
	this.player = new Player(planet);
  this.tabPlanet[0] = planet;
  this.tabPlayer[0] = this.player;
}

Game.prototype.PopulationRandom = function () {
	return Math.floor((Math.random() * 200) + 1);
};


Game.prototype.gameOver = function () {
  var bool = false;
  // on vérifie si au moins un ennemi peut joueur
  for (var i = 1; i < this.tabPlayer.length; i++) {
    // bool === false si tous les ennemis ne peuvent pas jouer
    bool = bool || this.tabPlayer[i].canPlay();
  } 
  // Le jeu termine quand le joueur ne peut plus joueur
  if (bool === true && this.player.canPlay()) {
    return false;
  } 
  return true; 
};

//Lancer une attaque
Game.prototype.launchAttack = function(s) {
  if (!(s instanceof Spaceship)) {
		throw new Error("Not spaceship");
  }
  if (s.coord.isEqual(s.enemy.coord)) {
    if (checkCoord(s.home.leader, s.enemy)) {
      s.enemy.population = s.occupants + s.enemy.population;
    } else {
      if (s.occupants > s.enemy.populaton) {
        s.enemy.population = s.occupants - s.enemy.population;
        // le jouuer devient le proprietaire de cette planète
        if (s.enemy.leader !== null) {
           s.enemy.leader.removePlanet(s.enemy);
        }
        s.home.leader.addPlanet(s.enemy);
        s.home.leader.removeSpaceship(s);
        this.destroySpaceShip(s);
        //~ var message = { 
                //~ planet: s.enemy,
                //~ string: " est tombée entre les mains de ",
                //~ joueur: s.home.leader};
        //~ return message;      
      } else {
        s.enemy.population = s.enemy.population - s.occupants;
        s.home.leader.removeSpaceship(s);
        this.destroySpaceShip(s);
        //~ var message = { 
                //~ planet: s.enemy,
                //~ string: " a tenu contre l’attaque de ",
                //~ joueur: s.home.leader};
        //~ return message;
      }
    }
  }
  //~ return null;
};

Game.prototype.destroySpaceShip = function(s) {
  if (s instanceof Spaceship) {
    this.fleet.pop(s);
  }
};

//tour
Game.prototype.turn = function() {
  if (!(this.gameOver())) {
    // Lancer des attaques pour les ennemis
    this.autoplay(); 
    
    //initialiser le tableau de flotte
    var newFleet = []; 
    for (var i = 0; i < this.tabPlayer.length; i++) {
      if (this.tabPlayer[i].getFleet.length > 0) {
        for (var j = 0; j < this.tabPlayer[i].getFleet.length; j++) {
          newFleet.push(this.tabPlayer[i].getFleet[j]); 
        }
      }
    }
    this.fleet = newFleet;

    // Déplacer les flottes en transit 
    this.move();
    
    // Criossance de population
    this.increasePopulation();
  }
};

// Déplacer les flottes en transit 
Game.prototype.move = function() {
  for (var i = 0; i < this.fleet.length; i++) {
    this.fleet[i].move();
    this.launchAttack(this.fleet[i]);
  }
};

// Ajouter une planète dans la flotte
Game.prototype.addSpaceship = function(s) {
	if (s instanceof Spaceship) {
		this.Fleet.push(s);
	}
};
        
//incremente la population de tous les planète dans l'univers
Game.prototype.increasePopulation = function() {
  for (var i = 0; i < this.tabPlanet.length; i++) {
    if (this.tabPlanet[i].leader !== null) {
      var n =  Math.floor((Math.random() * 10) + 1);
      this.tabPlanet[i].population += n;
    }
  }
};


Game.prototype.autoplay = function() {
  for (var i = 0; i < this.tabPlayer.length; i++) {
    //tableau pour stocker tous les planètes d'un joueur qui peut lancer un attaque
    var planetArray = []; 
    // retirer tous les planètes neutres dans les tableaux de joueurs
    var p = this.tabPlayer[i]; 
    for (var j = 0; j < p.getPlanets.length; j++) {
      if (p.getPlanets[j].population === 0) {
        p.removePlanet(p.getPlanets[j]); 
      }
      if (i !== 0 && p.getPlanets[j].population > 1) {
        planetArray.push(p.getPlanets[j]);
      }
    }
    // lancer des attaques pour ennemis
    // si il n'est pas le joueur principal
    if (i != 0 && planetArray.length > 0) {
      //pour tous les ennemis, on lance une attaque aléatoirement
      var ep = randomEnemyPlanet(planetArray);
      var rand = Math.floor((Math.random() * this.tabPlanet.length));
      var pt = this.tabPlanet[rand];
      var nbColonists = randomNColonists(ep);
      this.tabPlayer[i].attack(ep, nbColonists, pt);
    }
  }
};

// OUTILS
function randomPlanet() {
	var rand = Math.floor((Math.random() * this.tabPlanet.length));
  return this.tabPlanet[rand]; 
}

function randomEnemyPlanet(e) {
	var rand = Math.floor((Math.random() * e.length));
	return e[rand]; 
}

function randomNColonists(p) {
  return Math.floor((Math.random() * (p.population - 1)) + 1);
}

function checkCoord(player, planet) {
  if (player.getPlanets.length > 0) {
    for (var i = 0; i < player.getPlanets.length; i++) {
      if (player.getPlanets[i] === planet) {
        return true;
      }
    }
  }
  return false;
}
